<?php 
//gtbank//$site = 'http://careers.gtbank.com/';
$site = 'https://foundation.mtnonline.com/scholarship/stss';
header('Location:'.$site);

?>`
